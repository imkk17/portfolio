import pyxel
import math
import random
from jeu.entités.personnage import Personnage
from jeu.entités.projectile import Projectile
from jeu.entités.ennemis import Ennemis
from jeu.systeme.systeme_amelioration import system_damelioration
from jeu.systeme.game_over import GameOverSystem
from scores.Table import inserer_score_complet, get_classement_complet

class Jeu:
    def __init__(self, largeur=None, hauteur=None, difficulte="NORMAL"):
        if largeur is None or hauteur is None:
            self.taille_fenetre_x = 256 * 2
            self.taille_fenetre_y = self.taille_fenetre_x // 2
        else:
            self.taille_fenetre_x = largeur # maintenir un ratio 2:1
            self.taille_fenetre_y = hauteur # 2:1 ratio
        
        self.difficulte = difficulte
        
        self.character = Personnage(self.taille_fenetre_x, self.taille_fenetre_y, self.difficulte)
        self.upgrade_system = system_damelioration()
        self.game_over_system = GameOverSystem(self)
        self.projectiles = []
        self.enemies = []
        
        self.score = 0
        self.temps = 0
        self.game_over = False
        self.en_amelioration = False
        
        self.ennemi_spawn_timer = 0
        self.ennemi_spawn_delay = self.délai_d_apparition()
        self.ennemi_vitesse_base = self.vitesse_de_base()
        
        # Limite de projectiles pour éviter le lag
        self.projectile_limit = 100

    def délai_d_apparition(self):
        if self.difficulte == "FACILE":
            return 90
        elif self.difficulte == "NORMAL":
            return 60
        elif self.difficulte == "DIFFICILE":
            return 40
        elif self.difficulte == "EXPERT":
            return 30
        else:
            return 60

    def vitesse_de_base(self):
        if self.difficulte == "FACILE":
            return 0.6
        elif self.difficulte == "NORMAL":
            return 0.8
        elif self.difficulte == "DIFFICILE":
            return 1.0
        elif self.difficulte == "EXPERT":
            return 1.2
        else:
            return 0.8

    def multiplicateur_score(self):
        if self.difficulte == "FACILE":
            return 0.5
        elif self.difficulte == "NORMAL":
            return 1.0
        elif self.difficulte == "DIFFICILE":
            return 1.5
        elif self.difficulte == "EXPERT":
            return 2.0
        else:
            return 1.0

    def rénitiliasition_jeu(self):
        self.character = Personnage(self.taille_fenetre_x, self.taille_fenetre_y, self.difficulte)
        self.upgrade_system = system_damelioration()
        self.projectiles = []
        self.enemies = []
        self.score = 0
        self.temps = 0
        self.game_over = False
        self.en_amelioration = False
        self.game_over_system.reset()
        self.ennemi_spawn_timer = 0
        self.ennemi_spawn_delay = self.délai_d_apparition()

    def ajouter_xp(self, quantite):
        self.character.ajouter_xp(quantite, self.upgrade_system)

    def retirer_vie(self, quantite):
        self.character.retirer_vie(quantite)
        if self.character.vie <= 0:
            self.game_over = True
            self.game_over_system.temps_survie = self.temps // 30

    def ennemis_creation(self):
        self.ennemi_spawn_timer += 1
        if self.ennemi_spawn_timer >= self.ennemi_spawn_delay:
            self.ennemi_spawn_timer = 0
            self.ennemi_spawn_delay = max(20, self.ennemi_spawn_delay - 0.5)
            
            enemy = Ennemis.create_from_border(
                self.taille_fenetre_x,
                self.taille_fenetre_y,
                self.ennemi_vitesse_base + (self.score / 500) * self.multiplicateur_score()
            )
            self.enemies.append(enemy)

    def ennemis_deplacement(self):
        projectiles_a_supprimer = []
        ennemis_a_supprimer = []
        
        for ennemi in self.enemies[:]:
            ennemi.update()
            
            ennemi.move_towards(self.character.x, self.character.y)
            
            if ennemi.collides_with_character(self.character):
                self.retirer_vie(1)
                self.ajouter_xp(5)
                ennemis_a_supprimer.append(ennemi)
                if self.character.vie <= 0:
                    return
                continue
            
            for tir in self.projectiles[:]:
                if ennemi.collision_avec_projectiles(tir):
                    is_big_shot = self.upgrade_system.taille_tir_temporaire
                    est_mort = ennemi.subir_degats(1, is_big_shot)
                    
                    if tir not in projectiles_a_supprimer:
                        projectiles_a_supprimer.append(tir)
                    
                    if est_mort and ennemi not in ennemis_a_supprimer:
                        ennemis_a_supprimer.append(ennemi)
                    
                    break
        
        if ennemis_a_supprimer:
            self.enemies = [e for e in self.enemies if e not in ennemis_a_supprimer]
            for ennemi in ennemis_a_supprimer:
                base_score = 10 * ennemi.vie_max
                score_ajuste = base_score * self.multiplicateur_score()
                self.score += score_ajuste
                self.ajouter_xp(10 * ennemi.vie_max)
        
        if projectiles_a_supprimer:
            self.projectiles = [p for p in self.projectiles if p not in projectiles_a_supprimer]

    def tirs_creation(self):
        if len(self.projectiles) >= self.projectile_limit:
            return
            
        cooldown_actuel = 1 if self.upgrade_system.cooldown_temporaire else self.character.cooldown
        taille_tir_actuelle = 15 if self.upgrade_system.taille_tir_temporaire else self.character.tirs_taille
        
        if self.temps % cooldown_actuel == 0:
            projectile = Projectile.create_aimed(
                self.character.x + self.character.size_x/2,
                self.character.y + self.character.size_y/2,
                pyxel.mouse_x,
                pyxel.mouse_y,
                self.character.tirs_vitesse,
                taille_tir_actuelle
            )
            self.projectiles.append(projectile)

    def tirs_deplacement(self):
        projectiles_hors_ecran = []
        
        for i, tir in enumerate(self.projectiles[:]):
            tir.move()
            if tir.is_out_of_bounds(self.taille_fenetre_x, self.taille_fenetre_y):
                projectiles_hors_ecran.append(i)
        
        for index in reversed(projectiles_hors_ecran):
            self.projectiles.pop(index)

    def update(self):
        if self.game_over:
            self.game_over_system.update()
            return
            
        self.upgrade_system.update_temporary_upgrades(self.temps)
            
        if self.upgrade_system.en_amelioration:
            if pyxel.btnp(pyxel.MOUSE_BUTTON_LEFT):
                for i in range(len(self.upgrade_system.ameliorations_disponibles)):
                    y_pos = 80 + i * 45
                    if (pyxel.mouse_x >= 40 and pyxel.mouse_x <= self.taille_fenetre_x - 40 and 
                        pyxel.mouse_y >= y_pos and pyxel.mouse_y <= y_pos + 35):
                        self.upgrade_system.appliquer_amelioration(i, self.character, self.temps)
                        break
            return
            
        self.character.deplacer()
        self.temps += 1

        if self.temps % 30 == 0:
            base_increment = 0.4
            score_increment = base_increment * self.multiplicateur_score()
            self.score += score_increment

        self.tirs_creation()
        self.tirs_deplacement()
        self.ennemis_deplacement()
        self.ennemis_creation()
        
        if self.character.xp >= self.character.xp_max:
            self.upgrade_system.trigger_amelioration()
            
        pyxel.mouse(True)

    def draw(self):
        if self.game_over:
            self.game_over_system.draw()
            return
            
        pyxel.cls(0)
        pyxel.blt(197, 95, 1, 0, 0, 130, 63, scale=4.02) # la map de fond
        if self.upgrade_system.en_amelioration:
            self.upgrade_system.draw_menu(self.taille_fenetre_x, self.taille_fenetre_y, self.character)
            return

        score_text = f"SCORE: {int(self.score)}"
        score_width = len(score_text) * 4 + 8
        pyxel.rect(10, 5, score_width, 10, 1)
        pyxel.rectb(10, 5, score_width, 10, 7)
        pyxel.text(12, 7, score_text, 10)
        
        difficulte_text = f"DIFFICULTE: {self.difficulte}"
        difficulte_width = len(difficulte_text) * 4 + 8
        pyxel.rect(self.taille_fenetre_x - difficulte_width - 10, 5, difficulte_width, 10, 1)
        pyxel.rectb(self.taille_fenetre_x - difficulte_width - 10, 5, difficulte_width, 10, 7)
        pyxel.text(self.taille_fenetre_x - difficulte_width - 8, 7, difficulte_text, 13)
        
        multiplicateur = self.multiplicateur_score()
        if multiplicateur != 1.0:
            multi_text = f"x{multiplicateur}"
            pyxel.text(self.taille_fenetre_x // 2 - len(multi_text) * 2, 7, multi_text, 9)
        
        self.character.draw()
        
        for tir in self.projectiles[:self.projectile_limit]:
            tir.draw()
            
        for ennemi in self.enemies:
            ennemi.draw()

        self.character.draw_stats(self.upgrade_system, self.temps)