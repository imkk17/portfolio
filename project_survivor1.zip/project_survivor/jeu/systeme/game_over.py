import pyxel
import math
import random
# LIGNE CORRIGÉE - SEULEMENT 2 IMPORTS
from scores.Table import inserer_score_complet, get_classement_complet

class GameOverSystem:
    def __init__(self, jeu):
        self.jeu = jeu
        self.nom_joueur = ""
        self.ecran_game_over = "saisie_nom"  # "saisie_nom" ou "classement"
        self.animation_temps_game_over = 0
        self.lettre_hauteur = 20
        self.lettre_largeur = 16
        self.lettre_espacement = 4
        
        # Étoiles pour l'animation du fond (Game Over)
        self.etoiles = [
            (random.randint(0, jeu.taille_fenetre_x),
             random.randint(0, jeu.taille_fenetre_y),
             random.uniform(0.5, 2),
             random.choice([7, 8]))
            for _ in range(80)
        ]

    def reset(self):
        self.nom_joueur = ""
        self.ecran_game_over = "saisie_nom"
        self.animation_temps_game_over = 0

    def dessiner_fond_game_over(self):
        """Dessine le fond animé avec des étoiles (Game Over)"""
        pyxel.cls(0)
        for i, (x, y, vitesse, couleur) in enumerate(self.etoiles):
            c = 8 if random.random() < 0.05 else couleur
            pyxel.pset(x, y, c)
            self.etoiles[i] = (x, (y + vitesse) % self.jeu.taille_fenetre_y, vitesse, couleur)

    def dessiner_titre_game_over(self):
        """Dessine le titre GAME OVER avec animation"""
        titre = "GAME OVER"
        titre_largeur = len(titre) * (self.lettre_largeur + self.lettre_espacement) - self.lettre_espacement
        x_depart = (self.jeu.taille_fenetre_x - titre_largeur) // 2
        y_depart = 10  # Ajusté pour laisser de la place pour le tableau
        
        for i, lettre in enumerate(titre):
            compenser = math.sin(self.animation_temps_game_over * 2 + i * 0.4) * 4
            self.dessiner_lettre_game_over(lettre, x_depart + i * (self.lettre_largeur + self.lettre_espacement),
                                          y_depart + compenser, 7, i)

    def dessiner_lettre_game_over(self, lettre, x, y, couleur_base, index_lettre):
        """Dessine une lettre du titre GAME OVER"""
        self.dessiner_forme_lettre_game_over(lettre, x + 2, y + 2, 1)
        self.dessiner_forme_lettre_game_over(lettre, x, y, 8)

    def dessiner_forme_lettre_game_over(self, lettre, x, y, couleur):
        """Dessine la forme d'une lettre spécifique"""
        L = self.lettre_largeur
        H = self.lettre_hauteur
        if lettre == "G":
            pyxel.rect(x + 2, y + 2, L - 4, 4, couleur)
            pyxel.rect(x + 2, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + 2, y + H - 6, L - 4, 4, couleur)
            pyxel.rect(x + L - 6, y + 2, 4, H // 2, couleur)
            pyxel.rect(x + L // 2, y + H - 6, L // 2 - 4, 4, couleur)
        elif lettre == "A":
            pyxel.rect(x + 2, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + L - 6, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + 2, y + 2, L - 4, 4, couleur)
            pyxel.rect(x + 2, y + H//2 - 2, L - 4, 4, couleur)
        elif lettre == "M":
            pyxel.rect(x + 2, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + L - 6, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + L//2 - 2, y + 2, 4, H//3, couleur)
            pyxel.rect(x + L//2 - 6, y + H//3, 8, 4, couleur)
        elif lettre == "E":
            pyxel.rect(x + 2, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + 2, y + 2, L - 4, 4, couleur)
            pyxel.rect(x + 2, y + H//2 - 2, L - 4, 4, couleur)
            pyxel.rect(x + 2, y + H - 6, L - 4, 4, couleur)
        elif lettre == " ":
            pass
        elif lettre == "O":
            pyxel.rect(x + 2, y + 2, L - 4, H - 4, couleur)
            pyxel.rect(x + 6, y + 6, L - 12, H - 12, 0)
        elif lettre == "V":
            pyxel.rect(x + 2, y + 2, 4, H - 8, couleur)
            pyxel.rect(x + L - 6, y + 2, 4, H - 8, couleur)
            pyxel.tri(x + 2, y + H - 8, x + L//2, y + H - 2, x + L - 6, y + H - 8, couleur)
        elif lettre == "R":
            pyxel.rect(x + 2, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + 2, y + 2, L - 4, 4, couleur)
            pyxel.rect(x + L - 6, y + 2, 4, H//2 - 2, couleur)
            pyxel.rect(x + 2, y + H//2 - 2, L - 4, 4, couleur)
            pyxel.rect(x + L - 8, y + H//2, 4, H//2 - 4, couleur)

    def dessiner_saisie_nom(self):
        """Dessine l'écran de saisie du nom avec un design amélioré"""
        # Cadre principal
        cadre_x = self.jeu.taille_fenetre_x // 2 - 150
        cadre_y = 70
        cadre_w = 300
        cadre_h = 180
        
        # Fond du cadre
        pyxel.rect(cadre_x, cadre_y, cadre_w, cadre_h, 1)
        
        # Bordures stylisées
        for i in range(3):
            pyxel.rectb(cadre_x - i, cadre_y - i, cadre_w + 2*i, cadre_h + 2*i, 
                       8 if i == 0 else (7 if i == 1 else 13))
        
        # Titre
        pyxel.text(cadre_x + 100, cadre_y + 20, "ENREGISTREMENT", 8)
        pyxel.line(cadre_x + 20, cadre_y + 30, cadre_x + cadre_w - 20, cadre_y + 30, 7)
        
        # Statistiques dans un tableau simple
        stats_y = cadre_y + 45
        
        # Ligne 1: Score
        pyxel.rect(cadre_x + 30, stats_y, 240, 20, 0)
        pyxel.rectb(cadre_x + 30, stats_y, 240, 20, 7)
        pyxel.text(cadre_x + 40, stats_y + 6, f"SCORE: {int(self.jeu.score):,} points", 10)
        
        # Ligne 2: Temps
        temps_en_secondes = self.jeu.temps // 30
        pyxel.rect(cadre_x + 30, stats_y + 25, 240, 20, 0)
        pyxel.rectb(cadre_x + 30, stats_y + 25, 240, 20, 7)
        pyxel.text(cadre_x + 40, stats_y + 31, 
                  f"TEMPS: {temps_en_secondes//60:02d}min {temps_en_secondes%60:02d}sec", 9)
        
        # Saisie du nom
        saisie_y = stats_y + 60
        pyxel.text(cadre_x + 40, saisie_y, "Entre ton nom:", 7)
        
        # Champ de saisie
        champ_x = cadre_x + 40
        champ_y = saisie_y + 15
        champ_w = 220
        champ_h = 15
        
        # Fond du champ
        pyxel.rect(champ_x, champ_y, champ_w, champ_h, 0)
        pyxel.rectb(champ_x, champ_y, champ_w, champ_h, 7)
        
        # Curseur clignotant
        curseur = "_" if pyxel.frame_count % 30 < 15 else ""
        
        # Texte saisi
        texte_affiche = self.nom_joueur + curseur
        if len(texte_affiche) == 0:
            texte_affiche = "_" if pyxel.frame_count % 30 < 15 else ""
            pyxel.text(champ_x + 5, champ_y + 4, "Cliquez ici et tapez...", 13)
        else:
            pyxel.text(champ_x + 5, champ_y + 4, texte_affiche, 7)
        
        # Instructions
        instructions_y = champ_y + 30
        pyxel.text(cadre_x + 60, instructions_y, "Appuyez sur ENTREE pour valider", 8)
        
        # Astuce
        astuce_y = instructions_y + 15
        pyxel.text(cadre_x + 80, astuce_y, "(Maximum 12 caractères)", 13)

    def dessiner_classement(self):
        """Dessine l'écran du classement sous forme de tableau ajusté à la fenêtre"""
        classement = get_classement_complet()
        
        # Dimensions du tableau ajustées à la nouvelle position
        tableau_x = 10
        tableau_y = 35  # Position après le titre "GAME OVER"
        tableau_largeur = self.jeu.taille_fenetre_x - 20  # 10 de chaque côté
        tableau_hauteur = 180  # Augmenté de 160 à 180 pour afficher 10 scores au lieu de 8
        ligne_hauteur = 14     # Un peu plus grand pour la lisibilité
        
        # Dessiner le tableau avec un fond stylisé
        # Fond principal
        pyxel.rect(tableau_x, tableau_y, tableau_largeur, tableau_hauteur, 1)
        
        # Bordures stylisées
        for i in range(2):
            pyxel.rectb(tableau_x - i, tableau_y - i, 
                       tableau_largeur + 2*i, tableau_hauteur + 2*i, 
                       8 if i == 0 else 7)
        
        # Dessiner les en-têtes de colonnes
        en_tete_y = tableau_y + 5
        pyxel.rect(tableau_x, tableau_y, tableau_largeur, ligne_hauteur, 5)
        
        # Définir les colonnes avec largeurs ajustées pour la nouvelle largeur
        colonnes = [
            ("RANG", 50),    # Augmenté pour inclure l'émoji
            ("JOUEUR", 100), # Nom plus complet
            ("SCORE", 90),   # Pour les gros scores
            ("TEMPS", 70),   # Format mm:ss
            ("DATE", 80)     # JJ/MM
        ]
        
        # Dessiner les en-têtes avec positions ajustées
        x_pos = tableau_x + 10  # Marge interne
        for nom, largeur in colonnes:
            # Fond pour l'en-tête
            pyxel.rect(x_pos, en_tete_y, largeur, ligne_hauteur, 5)
            # Texte centré dans la colonne
            texte_x = x_pos + (largeur - len(nom) * 4) // 2
            if texte_x < x_pos:
                texte_x = x_pos
            pyxel.text(texte_x, en_tete_y + 4, nom, 1)  # Ombre
            x_pos += largeur
        
        # Ligne sous l'en-tête
        pyxel.line(tableau_x, tableau_y + ligne_hauteur, 
                  tableau_x + tableau_largeur, tableau_y + ligne_hauteur, 8)
        
        if not classement:
            # Message quand il n'y a pas de scores
            message = "AUCUN SCORE ENREGISTRÉ"
            pyxel.text(self.jeu.taille_fenetre_x // 2 - len(message)*2, 
                      tableau_y + 80, message, 7)
        else:
            # Afficher les scores (TOP 10 maintenant)
            for i, (nom, score, temps, date_str) in enumerate(classement[:10]):
                ligne_y = tableau_y + (i + 1) * ligne_hauteur + 5
                
                # Alterner les couleurs de fond pour les lignes
                if i % 2 == 0:
                    pyxel.rect(tableau_x + 1, ligne_y - 2, 
                              tableau_largeur - 2, ligne_hauteur, 0)
                else:
                    pyxel.rect(tableau_x + 1, ligne_y - 2, 
                              tableau_largeur - 2, ligne_hauteur, 1)
                
                # Couleur du texte selon le rang
                if i == 0:
                    couleur = 10  # Or
                    emoji = "1"
                elif i == 1:
                    couleur = 7   # Argent
                    emoji = "2"
                elif i == 2:
                    couleur = 8   # Bronze
                    emoji = "3"
                else:
                    couleur = 13  # Violet
                    emoji = f"{i+1}."
                
                # Formatage des données
                rang = emoji
                nom_affiche = nom[:10] if len(nom) <= 10 else nom[:7] + "..."  # Nom plus long possible
                score_affiche = f"{int(score):,}"
                mins = temps // 60
                secs = temps % 60
                temps_affiche = f"{mins}:{secs:02d}"
                
                # Formatage de la date (plus court)
                if isinstance(date_str, str) and " " in date_str:
                    date_parts = date_str.split(" ")[0].split("-")
                    date_affiche = f"{date_parts[2]}/{date_parts[1]}"  # JJ/MM seulement
                else:
                    date_affiche = str(date_str)[5:10] if len(str(date_str)) >= 10 else str(date_str)
                
                # Afficher les colonnes avec positions ajustées aux nouvelles coordonnées
                x_pos = tableau_x + 10
                colonnes_data = []
                
                # RANG
                colonnes_data.append((x_pos + 15, rang))
                x_pos += 50
                
                # JOUEUR
                colonnes_data.append((x_pos + 10, nom_affiche))
                x_pos += 100
                
                # SCORE
                score_text_x = x_pos + (90 - len(score_affiche) * 4) // 2
                if score_text_x < x_pos:
                    score_text_x = x_pos
                colonnes_data.append((score_text_x, score_affiche))
                x_pos += 90
                
                # TEMPS
                temps_text_x = x_pos + (70 - len(temps_affiche) * 4) // 2
                if temps_text_x < x_pos:
                    temps_text_x = x_pos
                colonnes_data.append((temps_text_x, temps_affiche))
                x_pos += 70
                
                # DATE
                date_text_x = x_pos + (80 - len(date_affiche) * 4) // 2
                if date_text_x < x_pos:
                    date_text_x = x_pos
                colonnes_data.append((date_text_x, date_affiche))
                
                # Dessiner toutes les colonnes
                for x, texte in colonnes_data:
                    pyxel.text(x, ligne_y + 4, str(texte), couleur)
        
        # Instructions ajustées à la nouvelle position
        instructions_box_y = tableau_y + tableau_hauteur + 5  # Ajusté de 15 à 5 pour plus d'espace
        pyxel.rect(self.jeu.taille_fenetre_x // 2 - 90, instructions_box_y - 5, 180, 35, 1)
        pyxel.rectb(self.jeu.taille_fenetre_x // 2 - 90, instructions_box_y - 5, 180, 35, 7)
        
        # Texte plus visible et clair
        pyxel.text(self.jeu.taille_fenetre_x // 2 - 50, instructions_box_y, 
                  "ESPACE - Rejouer", 10)
        pyxel.text(self.jeu.taille_fenetre_x // 2 - 35, instructions_box_y + 12, 
                  "ECHAP - QUITTER", 8)
        pyxel.text(self.jeu.taille_fenetre_x // 2 - 85, instructions_box_y + 24, 
                  "Votre score a ete sauvegarde!", 9)

    def update_saisie_nom(self):
        """Gère la saisie du nom dans l'écran Game Over"""
        if pyxel.btnp(pyxel.KEY_BACKSPACE):
            self.nom_joueur = self.nom_joueur[:-1]
        elif pyxel.btnp(pyxel.KEY_RETURN) and self.nom_joueur.strip():
            # Convertir le temps de frames en secondes pour la sauvegarde
            temps_en_secondes = self.jeu.temps // 30
            inserer_score_complet(self.nom_joueur.strip(), int(self.jeu.score), temps_en_secondes)
            self.ecran_game_over = "classement"
            return
        
        for key in range(pyxel.KEY_A, pyxel.KEY_Z + 1):
            if pyxel.btnp(key):
                if len(self.nom_joueur) < 12:
                    char = chr(key - pyxel.KEY_A + ord('A'))
                    if pyxel.btn(pyxel.KEY_SHIFT):
                        char = char.upper()
                    else:
                        char = char.lower()
                    self.nom_joueur += char
        
        for key in range(pyxel.KEY_0, pyxel.KEY_9 + 1):
            if pyxel.btnp(key):
                if len(self.nom_joueur) < 12:
                    self.nom_joueur += chr(key - pyxel.KEY_0 + ord('0'))

    def update_classement(self):
        """Gère les interactions dans l'écran du classement"""
        if pyxel.btnp(pyxel.KEY_SPACE):
            # Redémarrer le jeu
            self.jeu.rénitiliasition_jeu()
        elif pyxel.btnp(pyxel.KEY_ESCAPE):
            # Retourner au menu (nécessite d'importer Menu)
            try:
                from menu import Menu
                pyxel.quit()
                Menu()
            except ImportError:
                print("Impossible d'importer le menu. Redémarrage du jeu...")
                self.jeu.rénitiliasition_jeu()

    def update(self):
        """Méthode principale d'update pour le système Game Over"""
        self.animation_temps_game_over += 0.05
        
        if self.ecran_game_over == "saisie_nom":
            self.update_saisie_nom()
        else:
            self.update_classement()

    def draw(self):
        """Méthode principale de dessin pour le système Game Over"""
        self.dessiner_fond_game_over()
        self.dessiner_titre_game_over()
        
        if self.ecran_game_over == "saisie_nom":
            self.dessiner_saisie_nom()
        else:
            self.dessiner_classement()