import random
import pyxel

class system_damelioration:
    def __init__(self):
        self.niveau_amelioration = 0
        self.en_amelioration = False
        self.ameliorations_disponibles = []
        
        self.cooldown_temporaire = False
        self.cooldown_temporaire_timer = 0
        self.taille_tir_temporaire = False
        self.taille_tir_temporaire_timer = 0
        
        self.toutes_ameliorations = [
            {"nom": "Vitesse++", "description": "Vitesse de déplacement +20%", "effet": self.ameliorer_vitesse, "couleur": 9},
            {"nom": "Vie++", "description": "+1 vie maximum", "effet": self.ameliorer_vie, "couleur": 8},
            {"nom": "Tir Rapide", "description": "Cadence max pendant 5s", "effet": self.ameliorer_tir_rapide, "couleur": 13},
            {"nom": "Cadence++", "description": "Cadence de tir +3", "effet": self.ameliorer_cadence, "couleur": 11},
        ]

    def trigger_amelioration(self):
        self.en_amelioration = True
        self.generer_ameliorations()
        
    def generer_ameliorations(self):
        self.ameliorations_disponibles = random.sample(self.toutes_ameliorations, 3)
    
    def appliquer_amelioration(self, index, character, current_time):
        if 0 <= index < len(self.ameliorations_disponibles):
            if self.ameliorations_disponibles[index]["nom"] == "Tir Rapide":
                self.ameliorations_disponibles[index]["effet"](character, current_time)
            elif self.ameliorations_disponibles[index]["nom"] == "Gros Tirs":
                self.ameliorations_disponibles[index]["effet"](character, current_time)
            else:
                self.ameliorations_disponibles[index]["effet"](character)
            
            self.niveau_amelioration += 1
            character.xp = 0
            character.xp_max = int(character.xp_max * 1.2)
            self.en_amelioration = False
    
    def ameliorer_vitesse(self, character):
        character.vitesse *= 1.2
    
    def ameliorer_cadence(self, character):
        character.cooldown = max(5, character.cooldown - 3)
    

    
    def ameliorer_vie(self, character):
        character.vie_max += 1
        character.vie = character.vie_max
    
    def ameliorer_tir_rapide(self, character, current_time):
        self.cooldown_temporaire = True
        self.cooldown_temporaire_timer = current_time + 150
        

        
    def ameliorer_soin(self, character):
        if character.vie < character.vie_max:
            character.vie += 1

    def update_temporary_upgrades(self, current_time):
        if self.cooldown_temporaire and current_time >= self.cooldown_temporaire_timer:
            self.cooldown_temporaire = False
            
        if self.taille_tir_temporaire and current_time >= self.taille_tir_temporaire_timer:
            self.taille_tir_temporaire = False

    def draw_menu(self, screen_width, screen_height, character):
        for y in range(0, screen_height, 4):
            for x in range(0, screen_width, 4):
                if (x + y) % 8 == 0:
                    pyxel.rect(x, y, 4, 4, 1)
        
        pyxel.rect(20, 20, screen_width - 40, screen_height - 40, 0)
        pyxel.rectb(20, 20, screen_width - 40, screen_height - 40, 7)
        
        titre = "CHOISISSEZ UNE AMELIORATION"
        pyxel.rect(screen_width//2 - len(titre)*2 - 5, 35, len(titre)*4 + 10, 12, 5)
        pyxel.text(screen_width//2 - len(titre)*2, 38, titre, 7)
        
        pyxel.text(screen_width//2 - 15, 60, f"Niveau {self.niveau_amelioration + 1}", 7)
        
        for i, amelioration in enumerate(self.ameliorations_disponibles):
            y_pos = 80 + i * 45
            x_rect = 40
            largeur_rect = screen_width - 80
            hauteur_rect = 35
            
            souris_dessus = (pyxel.mouse_x >= x_rect and pyxel.mouse_x <= x_rect + largeur_rect and 
                            pyxel.mouse_y >= y_pos and pyxel.mouse_y <= y_pos + hauteur_rect)
            
            couleur_fond = amelioration["couleur"] if souris_dessus else 1
            pyxel.rect(x_rect, y_pos, largeur_rect, hauteur_rect, couleur_fond)
            pyxel.rectb(x_rect, y_pos, largeur_rect, hauteur_rect, 7)
            
            nom_x = x_rect + 30
            desc_x = x_rect + 30
            
            pyxel.text(nom_x, y_pos + 8, amelioration["nom"], 7)
            pyxel.text(desc_x, y_pos + 20, amelioration["description"], 13)
            
            pyxel.circ(x_rect + 15, y_pos + 18, 6, amelioration["couleur"])
        
        pyxel.text(screen_width//2 - 40, screen_height - 25, "CLIQUEZ POUR SELECTIONNER", 7)