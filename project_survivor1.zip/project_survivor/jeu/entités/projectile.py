import math
import pyxel

class Projectile:
    def __init__(self, x, y, dx, dy, size, character_x=None, character_y=None):
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.size = size
        
        # Stocker la position du personnage pour calculer l'angle
        self.character_x = character_x
        self.character_y = character_y
        
        # Calculer l'angle de rotation
        self.rotation_angle = self.calculer_angle_rotation()

    def calculer_angle_rotation(self):
        #Calcule l'angle de rotation basé sur d'où on tire
        if self.character_x is not None and self.character_y is not None:# Si la position du personnage est fournie
            # Calculer l'angle entre le personnage et la position de tir
            angle_rad = math.atan2(self.y - self.character_y, 
                                  self.x - self.character_x)
        else:
            # Sinon utiliser la direction du projectile
            if abs(self.dx) < 0.001 and abs(self.dy) < 0.001:# Éviter la division par zéro
                return 45  # Bas-droite par défaut
            angle_rad = math.atan2(self.dy, self.dx)# Calculer l'angle en radians
        
        # Convertir en degrés
        angle_deg = math.degrees(angle_rad)# Convertir en degrés
        
        # Ajuster pour que 0° = droite, 90° = bas, etc.
        # Si votre sprite de base pointe vers le bas-droite (45°)
        sprite_base_angle = 45# Angle de base du sprite
        
        # Calculer la rotation nécessaire
        return angle_deg - sprite_base_angle # Ajuster l'angle pour correspondre à l'orientation du sprite

    @classmethod
    def create_aimed(cls, start_x, start_y, target_x, target_y, speed, size, character_x=None, character_y=None):
        diff_x = target_x - start_x 
        diff_y = target_y - start_y# Calculer la norme
        norme = math.sqrt(diff_x**2 + diff_y**2) + 0.0001# Éviter la division par zéro
        dx = (diff_x / norme) * speed# Calculer les composantes de la vitesse
        dy = (diff_y / norme) * speed# Calculer les composantes de la vitesse
        return cls(start_x, start_y, dx, dy, size, character_x, character_y)# Créer une instance de Projectile

    def move(self):
        self.x += self.dx# Mettre à jour la position
        self.y += self.dy# Mettre à jour la position

    def is_out_of_bounds(self, screen_width, screen_height):
        return (self.y < 0 - self.size * 10 or # Vérifier si le projectile est hors de l'écran (ajusté pour la taille)
                self.y > screen_height + self.size * 10 or 
                self.x < 0 - self.size * 10 or 
                self.x > screen_width + self.size * 10)

    def draw(self):
        # Un seul sprite pour toutes les directions
        u, v = 14, 88# Coordonnées du sprite dans la tileset
        base_w, base_h = 26, 24# Taille de base du sprite
        
        # Calculer l'échelle basée sur self.size
        # self.size = 3 (normal), 15 (gros tirs), ou autre valeur (amélioration taille++)
        scale = self.size / 3.0  # Échelle relative à la taille normale (3)
        
        # Calculer les dimensions finales
        final_w = base_w * scale
        final_h = base_h * scale
        
        # Position centrée (ajustée pour la nouvelle taille)
        draw_x = self.x - final_w / 2
        draw_y = self.y - final_h / 2
        
        # Afficher avec rotation calculée et taille ajustée
        # Note: pyxel.blt utilise scale= pour redimensionner l'image
        pyxel.blt(
            draw_x, draw_y,  # Position
            2,               # Image bank 2
            u, v,            # Coordonnées du sprite dans la tileset
            base_w, base_h,  # Taille originale du sprite
            0,               # Couleur de transparence
            rotate=self.rotation_angle,  # Rotation
            scale=scale      # Échelle pour agrandir/rétrécir le sprite
        )