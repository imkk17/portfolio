# fichier: jeu/entities/personnage.py
import math
import pyxel

class Personnage:
    def __init__(self, screen_width, screen_height, difficulte="NORMAL"):
        # Ajuster les statistiques selon la difficulté
        if difficulte == "FACILE": # Plus de vie, tirs plus rapides
            self.vie_max = 7
            self.cooldown = 12  # Tirs plus rapides
            self.tirs_vitesse = 6  # Projectiles plus rapides
        elif difficulte == "NORMAL":
            self.vie_max = 5
            self.cooldown = 15
            self.tirs_vitesse = 5
        elif difficulte == "DIFFICILE":
            self.vie_max = 4
            self.cooldown = 18  # Tirs moins rapides
            self.tirs_vitesse = 4  # Projectiles plus lents
        elif difficulte == "EXPERT":
            self.vie_max = 3
            self.cooldown = 20  # Tirs beaucoup moins rapides
            self.tirs_vitesse = 3  # Projectiles très lents
        else:
            self.vie_max = 5
            self.cooldown = 15
            self.tirs_vitesse = 5
        
        self.vie = self.vie_max
        self.xp = 0
        self.xp_max = 100
        
        self.size_x = 31
        self.size_y = 46
        self.x = (screen_width / 2) - self.size_x/2
        self.y = (screen_height / 2) - self.size_y/2
        
        # Vitesse de déplacement selon la difficulté
        if difficulte == "FACILE":
            self.vitesse = 3.5  # Plus rapide
        elif difficulte == "NORMAL":
            self.vitesse = 3.0
        elif difficulte == "DIFFICILE":
            self.vitesse = 2.5  # Plus lent
        elif difficulte == "EXPERT":
            self.vitesse = 2.0  # Très lent
        else:
            self.vitesse = 3.0
            
        self.tirs_taille = 3
        self.direction = 1
        
        # Stocker les dimensions de l'écran
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.difficulte = difficulte

    def ajouter_xp(self, quantite, upgrade_system):
        self.xp += quantite
        if self.xp >= self.xp_max:
            self.xp = self.xp_max
            upgrade_system.trigger_amelioration()

    def retirer_vie(self, quantite):
        self.vie -= quantite
        if self.vie < 0:
            self.vie = 0

    def deplacer(self):
        deplacement_x = 0
        deplacement_y = 0
        
        # Utiliser les dimensions stockées au lieu de pyxel.width/height
        if (pyxel.btn(pyxel.KEY_RIGHT) or pyxel.btn(pyxel.KEY_D)) and self.x < self.screen_width - self.size_x:
            deplacement_x += self.vitesse
            self.direction = 1
        if (pyxel.btn(pyxel.KEY_LEFT) or pyxel.btn(pyxel.KEY_Q)) and self.x > 0:
            deplacement_x -= self.vitesse
            self.direction = -1
        if (pyxel.btn(pyxel.KEY_DOWN) or pyxel.btn(pyxel.KEY_S)) and self.y < self.screen_height - self.size_y:
            deplacement_y += self.vitesse
        if (pyxel.btn(pyxel.KEY_UP) or pyxel.btn(pyxel.KEY_Z)) and self.y > 0:
            deplacement_y -= self.vitesse
            
        if deplacement_x != 0 and deplacement_y != 0:
            deplacement_x /= math.sqrt(2)
            deplacement_y /= math.sqrt(2)
            
        self.x += deplacement_x
        self.y += deplacement_y

    def draw(self):
        if self.direction == 1:
            pyxel.blt(self.x, self.y, 0, 12, 47, -self.size_x, self.size_y, 0)
        else:
            pyxel.blt(self.x, self.y, 0, 12, 47, self.size_x, self.size_y, 0)

    def draw_stats(self, upgrade_system, temps):
        # Position ajustée pour ne pas chevaucher le score
        y_offset = 30  # Décalé vers le bas pour laisser de la place au score
        
        # Barre de vie
        pyxel.text(10, y_offset, f"Vie : {self.vie}/{self.vie_max}", 7)
        pyxel.rect(10, y_offset + 7, 100, 8, 0)
        largeur_vie = int((self.vie / self.vie_max) * 100)
        pyxel.rect(10, y_offset + 7, largeur_vie, 8, 8)

        # Barre d'XP
        # Barre d'XP avec bordure BLEUE CLAIRe
        pyxel.text(10, y_offset + 20, "XP :", 7)
        pyxel.rectb(10, y_offset + 27, 150, 8, 12)  # Bordure bleu clair
        pyxel.rect(10, y_offset + 27, 150, 8, 0)    # Fond noir
        largeur_xp = int((self.xp / self.xp_max) * 150)
        pyxel.rect(10, y_offset + 27, largeur_xp, 8, 12)  # Remplissage bleu clair
        
        # Affichage des améliorations actives
        y_offset += 40
        if upgrade_system.cooldown_temporaire:
            temps_restant = max(0, (upgrade_system.cooldown_temporaire_timer - temps) // 30)
            pyxel.text(10, y_offset, f"Tir rapide: {temps_restant}s", 11)
            y_offset += 8
        if upgrade_system.taille_tir_temporaire:
            temps_restant = max(0, (upgrade_system.taille_tir_temporaire_timer - temps) // 30)
            pyxel.text(10, y_offset, f"Gros tirs: {temps_restant}s", 12)
            y_offset += 8