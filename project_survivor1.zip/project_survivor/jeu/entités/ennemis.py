import math
import random
import pyxel

class Ennemis:
    def __init__(self, x, y, speed, model: int):
        self.x = x
        self.y = y
        self.speed = speed
        self.model = model
        self.dx = 0
        self.dy = 0
        
        # Définir les statistiques selon le modèle
        if self.model == 1:  # Petit squelette
            self.width = 16
            self.height = 26
            self.vie_max = 1  # Fragile
            self.points_vie = self.vie_max
        elif self.model == 2:  # Squelette avec faux (plus résistant)
            self.u = 0
            self.v = 36
            self.width = 32
            self.height = 32
            self.vie_max = 3  # Plus résistant
            self.points_vie = self.vie_max
        elif self.model == 3:  # Gargouille doré
            self.u = 43
            self.v = 0
            self.width = 41
            self.height = 52
            self.vie_max = 3  # Plus résistant
            self.points_vie = self.vie_max
        elif self.model == 4:  # Scorpion
            self.u = 1
            self.v = 122
            self.width = 39
            self.height = 48
            self.vie_max = 3  # Plus résistant
            self.points_vie = self.vie_max
        
        # Timer pour effet visuel quand touché
        self.hit_timer = 0

    @classmethod
    def create_from_border(cls, screen_width, screen_height, speed):
        if random.randint(1, 5) != 1:
            model = 1
        else:
            model = random.randint(1, 3) + 1
        
        # Définir les dimensions selon le modèle
        if model == 1:  # Petit squelette
            width, height = 16, 26
        else:  # Squelette avec faux
            width, height = 32, 32
        
        # Positionner l'ennemi en dehors de l'écran
        side = random.randint(0, 3)
        if side == 0:  # Haut
            x = random.randint(-width, screen_width + width)
            y = -height
        elif side == 1:  # Droite
            x = screen_width + width
            y = random.randint(-height, screen_height + height)
        elif side == 2:  # Bas
            x = random.randint(-width, screen_width + width)
            y = screen_height + height
        else:  # Gauche
            x = -width
            y = random.randint(-height, screen_height + height)
        
        return cls(x, y, speed, model)

    def move_towards(self, target_x, target_y):
        self.dx = target_x - self.x
        self.dy = target_y - self.y
        distance = math.sqrt(self.dx**2 + self.dy**2) + 0.0001
        self.x += (self.dx / distance) * self.speed
        self.y += (self.dy / distance) * self.speed
    
    def update(self):
        """Mettre à jour les timers"""
        if self.hit_timer > 0:
            self.hit_timer -= 1

    def subir_degats(self, degats=1, is_big_shot=False):
        """Inflige des dégâts à l'ennemi et retourne True s'il est mort"""
        # Si c'est un gros tir, infliger des dégâts massifs pour tuer instantanément
        if is_big_shot:
            degats = self.vie_max * 2  # Tuer instantanément
        
        self.points_vie -= degats
        self.hit_timer = 10  # Durée de l'effet visuel (10 frames)
        if self.points_vie <= 0:
            return True
        return False

    def est_vivant(self):
        """Vérifie si l'ennemi est toujours en vie"""
        return self.points_vie > 0

    def collides_with_character(self, character):
        # Collision rectangle-rectangle pour plus de précision
        return (character.x < self.x + self.width and
                character.x + character.size_x > self.x and
                character.y < self.y + self.height and
                character.y + character.size_y > self.y)

    def collision_avec_projectiles(self, projectile):
        """Collision rectangle-cercle précise"""
        # Coordonnées du rectangle
        rect_left = self.x
        rect_right = self.x + self.width
        rect_top = self.y
        rect_bottom = self.y + self.height
        
        # Trouver le point sur le rectangle le plus proche du centre du cercle
        closest_x = max(rect_left, min(projectile.x, rect_right))
        closest_y = max(rect_top, min(projectile.y, rect_bottom))
        
        # Calculer la distance entre ce point et le centre du cercle
        distance_x = projectile.x - closest_x
        distance_y = projectile.y - closest_y
        
        # Si la distance est inférieure au rayon, il y a collision
        distance_squared = distance_x * distance_x + distance_y * distance_y
        return distance_squared < (projectile.size * projectile.size)

    def draw(self):
        # Effet visuel quand touché
        couleur_alpha = 7  # Couleur normale
        if self.hit_timer > 0:
            couleur_alpha = 8  # Couleur rouge quand touché
            
        if self.model == 1:
            # petit squelette
            if self.dx > 0:
                pyxel.blt(self.x, self.y, 2, 6, 1, 16, 26, 0)
            else:
                pyxel.blt(self.x, self.y, 2, 6, 1, -16, 26, 0)
            
            # Barre de vie pour le petit squelette (seulement si plus d'1 PV)
            if self.vie_max > 1:
                vie_width = int((self.points_vie / self.vie_max) * self.width)
                pyxel.rect(self.x, self.y - 5, self.width, 3, 1)  # Fond
                pyxel.rect(self.x, self.y - 5, vie_width, 3, 8)  # Vie
        else:
            if self.model == 2:# squelette avec faux avec effet de dégât
                if self.dx > 0:
                    pyxel.blt(self.x, self.y, 2, self.u, self.v, self.width, self.height, 0)
                else:
                    pyxel.blt(self.x, self.y, 2, self.u, self.v, -self.width, self.height, 0)
            else: #Scorpion et Gargouille car sens inversé
                if self.dx > 0:
                    pyxel.blt(self.x, self.y, 2, self.u, self.v, -self.width, self.height, 0)
                else:
                    pyxel.blt(self.x, self.y, 2, self.u, self.v, self.width, self.height, 0)

            # Barre de vie pour le squelette avec faux (toujours affichée)
            vie_width = int((self.points_vie / self.vie_max) * self.width)
            pyxel.rect(self.x, self.y - 8, self.width, 4, 1)  # Fond
            pyxel.rect(self.x, self.y - 8, vie_width, 4, 8)  # Vie
            
            # Indicateur de résistance (affichage spécial pour le squelette avec faux)
            resistance_text = f"{self.points_vie}/{self.vie_max}"
            text_width = len(resistance_text) * 4
            pyxel.rect(self.x + self.width//2 - text_width//2 - 1, self.y - 12, 
                      text_width + 2, 6, 1)  # Fond du texte
            pyxel.text(self.x + self.width//2 - text_width//2, self.y - 11, 
                      resistance_text, 7 if self.points_vie > 1 else 8)