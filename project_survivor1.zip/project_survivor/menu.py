import pyxel
import math
import random 
from jeu.game import Jeu

class Menu:
    def __init__(self):
        self.taille_fenetre_x = 256 * 2
        self.taille_fenetre_y = self.taille_fenetre_x // 2
        
        try:
            pyxel.init(self.taille_fenetre_x, self.taille_fenetre_y, title="Menu Survivors")
            pyxel.colors[8] = 0xA7001E # couleur 
            pyxel.colors[14] = 0xA7001E
        except Exception as e:
            print("Erreur lors de l'initialisation de Pyxel :", e)
        
        try: # son 
            pyxel.sound(0).set("e0e0c1c1", "t", "7", "n", 10)
            pyxel.sound(1).set("g2g2e2e2", "p", "6", "v", 15)
            pyxel.sound(2).set("c1e1g1c2" * 4, "s", "4", "n", 30)
        except Exception as e:
            print("Erreur lors de la configuration des sons :", e)
        
        self.animation_temps = 0
        self.lettre_hauteur = 20
        self.lettre_largeur = 16
        self.lettre_espacement = 4
        self.transition_alpha = 0
        self.transitioning = False
        
        self.coloration_progress = [0.0] * len("SURVIVOR")
        self.all_letters_colored = False
        
        self.actuelle_menu = "main"
        self.selection_option = 0
        self.menu_option = {
            "main": ["Jouer", "Parametres", "Quitter"],
            "parametres": ["Son", "Difficulte", "Retour"]
        }
        
        self.son_actif = True
        self.difficulté = "NORMAL"
        self.jouer = False
        
        self.etoiles = [
            (random.randint(0, self.taille_fenetre_x),
             random.randint(0, self.taille_fenetre_y),
             random.uniform(0.5, 2),
             random.choice([7, 8]))
            for _ in range(80)
        ]
        
        if self.son_actif:
            pyxel.play(2, 2, loop=True)
        
        pyxel.run(self.update, self.draw)

    def dessiner_lettre(self, lettre, x, y, couleur_base, index_lettre): # dessiner une lettre avec effet de goutte
        self.dessiner_forme_lettre(lettre, x + 2, y + 2, 1)
        
        couleur = 8 if self.coloration_progress[index_lettre] >= 1.0 else 7
        self.dessiner_forme_lettre(lettre, x, y, couleur)
        
        if not self.all_letters_colored and random.random() < 0.7:
            goutte_x = x + self.lettre_largeur // 2 + random.randint(-2, 2)
            goutte_y = (self.animation_temps * 20) % (y + self.lettre_hauteur)
            
            for dx in range(-1, 2):
                for dy in range(-1, 2):
                    px, py = goutte_x + dx, goutte_y + dy
                    if 0 <= px < self.taille_fenetre_x and 0 <= py < self.taille_fenetre_y:
                        if dx == 0 and dy == 0:
                            pyxel.pset(px, py, 14)
                        elif random.random() < 0.7:
                            pyxel.pset(px, py, 14)
            
            if y <= goutte_y <= y + self.lettre_hauteur:
                self.coloration_progress = [1.0] * len(self.coloration_progress)
                self.all_letters_colored = True
                if self.son_actif:
                    pyxel.play(1, 1)

    def dessiner_forme_lettre(self, lettre, x, y, couleur): # dessiner la forme de la lettre
        L = self.lettre_largeur #16
        H = self.lettre_hauteur#20
        if lettre == "S":
            pyxel.rect(x + 2, y + 2, L - 4, 4, couleur)
            pyxel.rect(x + 2, y + 2, 4, H // 2 - 2, couleur)
            pyxel.rect(x + 2, y + H // 2 - 2, L - 4, 4, couleur)
            pyxel.rect(x + L - 6, y + H // 2 - 2, 4, H // 2 - 2, couleur)
            pyxel.rect(x + 2, y + H - 6, L - 4, 4, couleur)
        elif lettre == "U":
            pyxel.rect(x + 2, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + L - 6, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + 2, y + H - 6, L - 4, 4, couleur)
        elif lettre == "R":
            pyxel.rect(x + 2, y + 2, 4, H - 4, couleur)
            pyxel.rect(x + 2, y + 2, L - 4, 4, couleur)
            pyxel.rect(x + L - 6, y + 2, 4, H // 2 - 2, couleur)
            pyxel.rect(x + 2, y + H // 2 - 2, L - 4, 4, couleur)
            pyxel.rect(x + L - 8, y + H // 2, 4, H // 2 - 4, couleur)
        elif lettre == "V":
            pyxel.rect(x + 2, y + 2, 4, H - 8, couleur)
            pyxel.rect(x + L - 6, y + 2, 4, H - 8, couleur)
            pyxel.tri(x + 2, y + H - 8, x + L // 2, y + H - 2, x + L - 6, y + H - 8, couleur)
        elif lettre == "I":
            pyxel.rect(x + L // 2 - 2, y + 2, 4, H - 4, couleur)
        elif lettre == "O":
            pyxel.rect(x + 2, y + 2, L - 4, H - 4, couleur)
            pyxel.rect(x + 6, y + 6, L - 12, H - 12, 0)

    def dessiner_fond(self): # dessiner le fond avec des étoiles grace au tp 
        pyxel.cls(0)
        for i, (x, y, vitesse, couleur) in enumerate(self.etoiles):
            dessiner_couleur = 7 if random.random() < 0.05 else couleur
            pyxel.pset(x, y, dessiner_couleur)
            self.etoiles[i] = (x, (y + vitesse) % self.taille_fenetre_y, vitesse, couleur)

    def dessiner_titre(self): # dessiner le titre avec effet de vague
        titre = "SURVIVOR"
        titre_largeur = len(titre) * (self.lettre_largeur + self.lettre_espacement) - self.lettre_espacement
        x_depart = (self.taille_fenetre_x - titre_largeur) // 2
        y_depart = self.taille_fenetre_y // 3
        
        for i, lettre in enumerate(titre):
            compenser = math.sin(self.animation_temps * 2 + i * 0.3) * 3
            self.dessiner_lettre(lettre, x_depart + i * (self.lettre_largeur + self.lettre_espacement),
                                 y_depart + compenser, 7, i)

    def dessiner_menu_options(self): # dessiner les options du menu
        y_depart = self.taille_fenetre_y * 2 // 3
        options = self.menu_option[self.actuelle_menu][:]

        if self.actuelle_menu == "parametres":
            options[0] = f"SON: {'ACTIF' if self.son_actif else 'DÉSACTIVÉ'}"
            options[1] = f"DIFFICULTÉ: {self.difficulté}"

        for i, option in enumerate(options):
            texte_largeur = len(option) * 4
            x = (self.taille_fenetre_x - texte_largeur) // 2
            y = y_depart + i * 20
            
            survol = (x <= pyxel.mouse_x <= x + texte_largeur and y <= pyxel.mouse_y <= y + 8)
            
            if i == self.selection_option and pyxel.frame_count % 60 < 45:
                pyxel.text(x - 12, y, ">", 8)
            
            couleur = 8 if survol else (7 if i == self.selection_option else 13)
            pyxel.text(x, y, option, couleur)

    def dessiner_controles(self): # dessiner les controles
        text = "FLÈCHES: NAVIGUER | ESPACE: SÉLECTIONNER"
        x = (self.taille_fenetre_x - len(text) * 4) // 2
        pyxel.text(x, self.taille_fenetre_y - 15, text, 8)

    def dessiner_credits(self): # dessiner les credits
        credits = "fait par spicethrower, valogalo, safya"
        x = (self.taille_fenetre_x - len(credits) * 4) // 2
        couleur = 13
        
        pyxel.rect(x - 2, self.taille_fenetre_y - 35, len(credits) * 4 + 4, 8, 0)
        pyxel.text(x, self.taille_fenetre_y - 33, credits, couleur)

    def dessiner_transition(self): # dessiner la transition
        if self.transitioning:
            for x in range(0, self.taille_fenetre_x, 3):
                for y in range(0, self.taille_fenetre_y, 3):
                    if random.random() < self.transition_alpha:
                        couleur = min(int(self.transition_alpha * 15), 15)
                        pyxel.pset(x, y, couleur)

    def update(self):# mettre a jour le menu
        self.animation_temps += 0.05
        pyxel.mouse(True)
        
        self.all_letters_colored = all(p >= 1.0 for p in self.coloration_progress)
        
        if self.transitioning:
            self.transition_alpha += 0.04
            if self.transition_alpha >= 1:
                self.executer_action()
            return
        
        options = self.menu_option[self.actuelle_menu]
        y_depart = self.taille_fenetre_y * 2 // 3
        
        if pyxel.btnp(pyxel.KEY_DOWN) or pyxel.btnp(pyxel.KEY_S):
            self.selection_option = (self.selection_option + 1) % len(options)
            if self.son_actif: pyxel.play(0, 0)
        if pyxel.btnp(pyxel.KEY_UP) or pyxel.btnp(pyxel.KEY_Z):
            self.selection_option = (self.selection_option - 1) % len(options)
            if self.son_actif: pyxel.play(0, 0)

        for i in range(len(options)):
            option = options[i]
            if self.actuelle_menu == "parametres":
                if i == 0: option = f"SON: {'ACTIF' if self.son_actif else 'DÉSACTIVÉ'}"
                elif i == 1: option = f"DIFFICULTÉ: {self.difficulté}"
            texte_largeur = len(option) * 4
            x = (self.taille_fenetre_x - texte_largeur) // 2
            y = y_depart + i * 20
            if x <= pyxel.mouse_x <= x + texte_largeur and y <= pyxel.mouse_y <= y + 8:
                if self.selection_option != i:
                    self.selection_option = i
                    if self.son_actif: pyxel.play(0, 0)
                if pyxel.btnp(pyxel.MOUSE_BUTTON_LEFT):
                    self.handle_selection()

        if pyxel.btnp(pyxel.KEY_SPACE) or pyxel.btnp(pyxel.KEY_RETURN):  
            self.handle_selection()

    def handle_selection(self):
        if self.son_actif:
            pyxel.play(1, 1)
        
        if self.actuelle_menu == "parametres":
            if self.selection_option == 0:
                self.son_actif = not self.son_actif
                if self.son_actif:
                    pyxel.play(2, 2, loop=True)
                else:
                    pyxel.stop(2)
            elif self.selection_option == 1:
                difficultés = ["FACILE", "NORMAL", "DIFFICILE", "EXPERT"]
                idx = difficultés.index(self.difficulté)
                self.difficulté = difficultés[(idx + 1) % len(difficultés)]
            else:
                self.transitioning = True
                self.transition_alpha = 0
        else:
            self.transitioning = True
            self.transition_alpha = 0

    def executer_action(self):# exécuter l'action selectionnée
        if self.actuelle_menu == "main":
            if self.selection_option == 0:
                if self.son_actif:
                    pyxel.stop(2)
                
                jeu = Jeu(self.taille_fenetre_x, self.taille_fenetre_y, self.difficulté)
                
                pyxel.load("res.pyxres")
                
                pyxel.run(jeu.update, jeu.draw)
                
            elif self.selection_option == 1:
                self.actuelle_menu = "parametres"
                self.selection_option = 0
            elif self.selection_option == 2:
                pyxel.quit()
        elif self.actuelle_menu == "parametres" and self.selection_option == 2:
            self.actuelle_menu = "main"
            self.selection_option = 0
        
        self.transitioning = False
        self.transition_alpha = 0

    def draw(self):
        self.dessiner_fond()
        self.dessiner_titre()
        self.dessiner_menu_options()
        self.dessiner_controles()
        self.dessiner_credits()
        self.dessiner_transition()

if __name__ == "__main__":
    Menu()