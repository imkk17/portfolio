
import sqlite3
from datetime import datetime

def creer_table_scores():
    """Crée la table Scores si elle n'existe pas"""
    conn = sqlite3.connect("scores.db")
    cursor = conn.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS Scores(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL,
        score INTEGER NOT NULL,
        temps_survie INTEGER NOT NULL,
        date TEXT NOT NULL
    )""")
    conn.commit()
    conn.close()
    return True

def inserer_score_complet(nom_joueur, score, temps_survie):
    """Insère un score complet avec nom, score et temps de survie"""
    conn = sqlite3.connect("scores.db")
    cursor = conn.cursor()
    nom = nom_joueur.strip() if nom_joueur and nom_joueur.strip() else "Anonyme"
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute("""INSERT INTO Scores(nom, score, temps_survie, date) 
                   VALUES(?, ?, ?, ?)""", (nom, score, temps_survie, date))
    conn.commit()
    print(f"Score sauvegardé: {nom} - {score} points - {temps_survie}s")
    conn.close()
    return True

def get_classement_complet():
    """Récupère le classement top 10"""
    conn = sqlite3.connect("scores.db")
    cursor = conn.cursor()
    cursor.execute("""SELECT nom, score, temps_survie, date 
                   FROM Scores 
                   ORDER BY score DESC 
                   LIMIT 10""")
    resultats = cursor.fetchall()
    conn.close()
    return resultats

def vider_table_scores():
    """Vide la table Scores"""
    conn = sqlite3.connect("scores.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Scores")
    conn.commit()
    print("Table Scores vidée.")
    conn.close()
    return True

# Initialiser la table au chargement
creer_table_scores()
